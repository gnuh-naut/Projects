package objects.Interface;

 public interface Health {
     void subHealth(double damage);
}
